# Renderer parity diagnostic

Exported from [Tessellate](https://github.com/danishgm-sketch/Tessellate) on 2026-10-18T01:36:00.762Z.

Shared fixture for Workbench and standalone export rendering checks.

## Tech Stack
- **Framework:** React 19 + TypeScript
- **Styling:** Tailwind CSS 4
- **Bundler:** Vite 6

## Getting Started

Install dependencies:
```bash
pnpm install
# or: npm install / yarn install
```

Run the development server:
```bash
pnpm dev
```

Build for production:
```bash
pnpm build
```

## Design DNA
- **Archetype:** analytics
- **Visual Mode:** dark
- **Geometry:** sharp-structural
- **Visual Ambition:** 75/100
- **Surface:** layered-dark-panels
