# Adaptive Architecture — Employee experience

Exported from [Tessellate](https://github.com/danishgm-sketch/Tessellate) on 2026-10-18T01:16:24.732Z.

Build a professional but playful employee experience platform for a 500-person technology company. The marketing site should feel warm and energetic, while the application itself should feel professional, fast and trustworthy. Make the dashboard refined, make onboarding playful, keep settings conservative.

## Tech Stack
- **Framework:** React 19 + TypeScript
- **Styling:** Tailwind CSS 4
- **Bundler:** Vite 6

## Getting Started

Install dependencies:
```bash
pnpm install
# or: npm install / yarn install
```

Run the development server:
```bash
pnpm dev
```

Build for production:
```bash
pnpm build
```

## Design DNA
- **Archetype:** recruitment
- **Visual Mode:** dark
- **Geometry:** pill
- **Visual Ambition:** 40/100
- **Surface:** subtle-contrast
