import React, { useState, useEffect } from 'react';
import { MarketingHome } from './screens/MarketingHome';
import { TeamOverview } from './screens/TeamOverview';
import { PeopleDirectory } from './screens/PeopleDirectory';
import { EmployeeProfile } from './screens/EmployeeProfile';
import { Teams } from './screens/Teams';
import { Onboarding } from './screens/Onboarding';
import { Engagement } from './screens/Engagement';
import { SettingsPolicies } from './screens/SettingsPolicies';
import { SignIn } from './screens/SignIn';

export default function App() {
  const screens = ["screen-marketing-home","screen-overview","screen-collection-index","screen-entity-detail","screen-teams","screen-onboarding","screen-engagement","screen-settings","screen-sign-in"];
  const readScreen=()=>screens.includes(location.hash.slice(1)) ? location.hash.slice(1) : screens[0];
  const [activeScreenId,setActiveScreenId]=useState(readScreen);
  const navigate=(id:string)=>{location.hash=id;setActiveScreenId(id);};
  useEffect(()=>{const handle=()=>setActiveScreenId(readScreen());window.addEventListener('hashchange',handle);return ()=>window.removeEventListener('hashchange',handle);},[]);


  const renderActiveScreen = () => {
    switch (activeScreenId) {
      case "screen-marketing-home": return <MarketingHome />;
      case "screen-overview": return <TeamOverview />;
      case "screen-collection-index": return <PeopleDirectory />;
      case "screen-entity-detail": return <EmployeeProfile />;
      case "screen-teams": return <Teams />;
      case "screen-onboarding": return <Onboarding />;
      case "screen-engagement": return <Engagement />;
      case "screen-settings": return <SettingsPolicies />;
      case "screen-sign-in": return <SignIn />;
      default:
        return <MarketingHome />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--tess-canvas,#FAF9F6)] text-[var(--tess-ink,#111217)] font-sans">
      {/* Top Navigation */}
      <div className="border-b border-[var(--tess-hairline,#D9D6CF)] bg-[var(--tess-surface)] px-4 py-3 flex flex-col sm:flex-row sm:flex-wrap gap-3 items-start sm:items-center justify-between">
        <div className="font-bold text-sm tracking-tight">{"Adaptive Architecture — Employee experience"}</div>
        <div aria-label="Project screens" role="group" className="flex flex-nowrap items-center gap-2 min-w-0 max-w-full overflow-x-auto whitespace-nowrap pb-1">
          <button
            aria-pressed={activeScreenId==="screen-marketing-home"} onClick={() => navigate("screen-marketing-home")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-marketing-home"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Marketing Home"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-overview"} onClick={() => navigate("screen-overview")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-overview"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Team Overview"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-collection-index"} onClick={() => navigate("screen-collection-index")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-collection-index"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"People Directory"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-entity-detail"} onClick={() => navigate("screen-entity-detail")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-entity-detail"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Employee Profile"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-teams"} onClick={() => navigate("screen-teams")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-teams"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Teams"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-onboarding"} onClick={() => navigate("screen-onboarding")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-onboarding"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Onboarding"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-engagement"} onClick={() => navigate("screen-engagement")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-engagement"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Engagement"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-settings"} onClick={() => navigate("screen-settings")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-settings"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Settings & Policies"}
          </button>
          <button
            aria-pressed={activeScreenId==="screen-sign-in"} onClick={() => navigate("screen-sign-in")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-sign-in"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Sign In"}
          </button>
        </div>
      </div>

      {/* Screen Container */}
      <main className="flex-1">
        {renderActiveScreen()}
      </main>
    </div>
  );
}
