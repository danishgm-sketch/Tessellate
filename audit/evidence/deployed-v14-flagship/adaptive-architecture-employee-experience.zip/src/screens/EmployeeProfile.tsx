import React from 'react';
import { AdvancedDataTable } from '../components/AdvancedDataTable';
import { EntityProfileHeader } from '../components/EntityProfileHeader';
import { MinimalTopNav } from '../components/MinimalTopNav';

export function EmployeeProfile() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-entity-detail"}>
            <div className={"tess-node tess-layout-workspace-dock-shell "} data-resource-variant={"nocturne"} data-node-id={"root-screen-entity-detail"} data-semantic-role={"workspace-dock-shell"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-navigation"} data-resource-variant={"nocturne"} data-node-id={"node-screen-entity-detail-navigation-1"} data-semantic-role={"navigation"} style={({}) as React.CSSProperties}><MinimalTopNav variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Onboarding","href":"#screen-onboarding"},{"label":"Engagement","href":"#screen-engagement"},{"label":"Settings & Policies","href":"#screen-settings"}]} orientation={"vertical"} /></div>
        <div className={"tess-node tess-layout-workspace-multi-pane "} data-resource-variant={"nocturne"} data-node-id={"container-screen-entity-detail-canvas"} data-semantic-role={"workspace-multi-pane"} style={({}) as React.CSSProperties}>
          <div className={"@container tess-node tess-layout-entity-header"} data-resource-variant={"nocturne"} data-node-id={"node-screen-entity-detail-entity-header-2"} data-semantic-role={"entity-header"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"Employee Profile"} subtitle={"Deep inspection, metadata attributes, timeline, and actions for a single employee."} badge={"EXAMPLE"} initials={"PC"} /></div>
          <div className={"@container tess-node tess-layout-detail-tabs"} data-resource-variant={"nocturne"} data-node-id={"node-screen-entity-detail-detail-tabs-3"} data-semantic-role={"detail-tabs"} style={({}) as React.CSSProperties}><MinimalTopNav variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Onboarding","href":"#screen-onboarding"},{"label":"Engagement","href":"#screen-engagement"},{"label":"Settings & Policies","href":"#screen-settings"}]} /></div>
          <div className={"@container tess-node tess-layout-main-content-pane"} data-resource-variant={"nocturne"} data-node-id={"node-screen-entity-detail-main-content-pane-4"} data-semantic-role={"main-content-pane"} style={({}) as React.CSSProperties}><AdvancedDataTable variant={"nocturne"} title={"Employee Profile"} rows={[{"id":1,"name":"Example colleague A","type":"Product team","quality":80,"status":"Onboarding"},{"id":2,"name":"Example colleague B","type":"Engineering team","quality":100,"status":"Settled in"},{"id":3,"name":"Example colleague C","type":"People team","quality":40,"status":"Welcome week"}]} columnLabels={{"name":"Colleague","type":"Team","quality":"Progress","status":"Status"}} /></div>
          <div className={"@container tess-node tess-layout-metadata-sidebar"} data-resource-variant={"nocturne"} data-node-id={"node-screen-entity-detail-metadata-sidebar-5"} data-semantic-role={"metadata-sidebar"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"Employee Profile"} subtitle={"Deep inspection, metadata attributes, timeline, and actions for a single employee."} badge={"EXAMPLE"} initials={"PC"} /></div>
        </div>
      </div>
    </div>
  );
}
