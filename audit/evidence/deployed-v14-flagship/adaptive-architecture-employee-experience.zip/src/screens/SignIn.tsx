import React from 'react';
import { Button } from '../components/Button';
import { Input } from '../components/Input';

export function SignIn() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-sign-in"}>
            <div className={"tess-node tess-layout-workspace-dock-shell "} data-resource-variant={"nocturne"} data-node-id={"root-screen-sign-in"} data-semantic-role={"workspace-dock-shell"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-auth-card"} data-resource-variant={"nocturne"} data-node-id={"node-screen-sign-in-auth-card-1"} data-semantic-role={"auth-card"} style={({}) as React.CSSProperties}><Input variant={"nocturne"} label={"Work email"} helperText={"Example field. Connect persistence and your backend in the exported application."} /></div>
        <div className={"tess-node tess-layout-workspace-multi-pane "} data-resource-variant={"nocturne"} data-node-id={"container-screen-sign-in-canvas"} data-semantic-role={"workspace-multi-pane"} style={({}) as React.CSSProperties}>
          <div className={"@container tess-node tess-layout-auth-footer"} data-resource-variant={"nocturne"} data-node-id={"node-screen-sign-in-auth-footer-2"} data-semantic-role={"auth-footer"} style={({}) as React.CSSProperties}><Button variant={"nocturne"} disabled={true}>{"Authentication backend required"}</Button></div>
        </div>
      </div>
    </div>
  );
}
