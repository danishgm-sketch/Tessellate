import React from 'react';
import { AdvancedDataTable } from '../components/AdvancedDataTable';
import { DashboardKpiGrid } from '../components/DashboardKpiGrid';
import { EntityProfileHeader } from '../components/EntityProfileHeader';
import { MinimalTopNav } from '../components/MinimalTopNav';
import { NotificationCentre } from '../components/NotificationCentre';

export function Engagement() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-engagement"}>
            <div className={"tess-node tess-layout-workspace-dock-shell "} data-resource-variant={"nocturne"} data-node-id={"root-screen-engagement"} data-semantic-role={"workspace-dock-shell"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-navigation"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-navigation-1"} data-semantic-role={"navigation"} style={({}) as React.CSSProperties}><MinimalTopNav variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Onboarding","href":"#screen-onboarding"},{"label":"Engagement","href":"#screen-engagement"},{"label":"Settings & Policies","href":"#screen-settings"}]} orientation={"vertical"} /></div>
        <div className={"tess-node tess-layout-workspace-multi-pane "} data-resource-variant={"nocturne"} data-node-id={"container-screen-engagement-canvas"} data-semantic-role={"workspace-multi-pane"} style={({}) as React.CSSProperties}>
          <div className={"@container tess-node tess-layout-overview-header"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-overview-header-2"} data-semantic-role={"overview-header"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"Engagement"} subtitle={"Review employee feedback and recognition"} badge={"EXAMPLE"} initials={"PC"} /></div>
          <div className={"@container tess-node tess-layout-metric-cards"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-metric-cards-3"} data-semantic-role={"metric-cards"} style={({}) as React.CSSProperties}><DashboardKpiGrid variant={"nocturne"} title={"Your organisation at a glance"} cards={[{"label":"People","val":"500","status":"From your brief · example"},{"label":"Onboarding","val":"12","status":"Sample journeys"},{"label":"Team pulse","val":"Positive","status":"Illustrative feedback"}]} /></div>
          <div className={"@container tess-node tess-layout-activity-feed"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-activity-feed-4"} data-semantic-role={"activity-feed"} style={({}) as React.CSSProperties}><NotificationCentre variant={"nocturne"} title={"People updates"} events={[{"time":"Today","title":"Welcome to the team","desc":"Meet your onboarding buddy and introduce yourself to colleagues."},{"time":"This week","title":"Team check-in","desc":"Share how your first week is going and ask for support."},{"time":"Next milestone","title":"Policies and preferences","desc":"Review organisational guidance and choose your notification preferences."}]} /></div>
          <div className={"@container tess-node tess-layout-data-table"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-data-table-5"} data-semantic-role={"data-table"} style={({}) as React.CSSProperties}><AdvancedDataTable variant={"nocturne"} title={"People and teams"} rows={[{"id":1,"name":"Example colleague A","type":"Product team","quality":80,"status":"Onboarding"},{"id":2,"name":"Example colleague B","type":"Engineering team","quality":100,"status":"Settled in"},{"id":3,"name":"Example colleague C","type":"People team","quality":40,"status":"Welcome week"}]} columnLabels={{"name":"Colleague","type":"Team","quality":"Progress","status":"Status"}} /></div>
        </div>
      </div>
    </div>
  );
}
