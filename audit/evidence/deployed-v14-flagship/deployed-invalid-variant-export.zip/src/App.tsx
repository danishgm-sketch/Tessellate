import React, { useState, useEffect } from 'react';
import { Overview } from './screens/Overview';

export default function App() {
  const screens = ["scr_inst_overview"];
  const readScreen=()=>screens.includes(location.hash.slice(1)) ? location.hash.slice(1) : screens[0];
  const [activeScreenId,setActiveScreenId]=useState(readScreen);
  const navigate=(id:string)=>{location.hash=id;setActiveScreenId(id);};
  useEffect(()=>{const handle=()=>setActiveScreenId(readScreen());window.addEventListener('hashchange',handle);return ()=>window.removeEventListener('hashchange',handle);},[]);


  const renderActiveScreen = () => {
    switch (activeScreenId) {
      case "scr_inst_overview": return <Overview />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--tess-canvas,#FAF9F6)] text-[var(--tess-ink,#111217)] font-sans">
      {/* Top Navigation */}
      <div className="border-b border-[var(--tess-hairline,#D9D6CF)] bg-[var(--tess-surface)] px-4 py-3 flex flex-col sm:flex-row sm:flex-wrap gap-3 items-start sm:items-center justify-between">
        <div className="font-bold text-sm tracking-tight">{"Unsupported variant diagnostic"}</div>
        <div aria-label="Project screens" role="group" className="flex flex-nowrap items-center gap-2 min-w-0 max-w-full overflow-x-auto whitespace-nowrap pb-1">
          <button
            aria-pressed={activeScreenId==="scr_inst_overview"} onClick={() => navigate("scr_inst_overview")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "scr_inst_overview"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Overview"}
          </button>
        </div>
      </div>

      {/* Screen Container */}
      <main className="flex-1">
        {renderActiveScreen()}
      </main>
    </div>
  );
}
