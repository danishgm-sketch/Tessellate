import React from 'react';
import { Button } from '../components/Button';
import { CanvasWorkspaceShell } from '../components/CanvasWorkspaceShell';
import { Dialog } from '../components/Dialog';

export function Overview() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"scr_inst_overview"}>
            <div className={"tess-node tess-layout-container "} data-resource-variant={"nocturne"} data-node-id={"node_shell_01"} data-semantic-role={"container"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-application-shell"} data-resource-variant={"expressive"} data-node-id={"parity-resource-prop-children"} data-semantic-role={"application-shell"} style={({}) as React.CSSProperties}><CanvasWorkspaceShell variant={"expressive"}>{"Content from resource props"}
          <div className={"tess-node tess-layout-content "} data-resource-variant={"nocturne"} data-node-id={"parity-prop-nested-child"} data-semantic-role={"content"} style={({}) as React.CSSProperties}>{"Content from nested manifest node"}</div>
        </CanvasWorkspaceShell></div>
        <div className={"@container tess-node tess-layout-application-shell"} data-resource-variant={"expressive"} data-node-id={"parity-resource-slot-children"} data-semantic-role={"application-shell"} style={({}) as React.CSSProperties}><CanvasWorkspaceShell variant={"expressive"}>{"Content from declared resource slot"}
          <div className={"tess-node tess-layout-content "} data-resource-variant={"nocturne"} data-node-id={"parity-slot-nested-child"} data-semantic-role={"content"} style={({}) as React.CSSProperties}>{"Content from nested manifest node"}</div>
        </CanvasWorkspaceShell></div>
        <div className={"@container tess-node tess-layout-action-button"} data-resource-variant={"expressive"} data-node-id={"parity-data-attribute-action"} data-semantic-role={"action-button"} style={({}) as React.CSSProperties}><Button variant={"expressive"} aria-label={"Parity action"} data-tracking-id={"parity-action"}>{"Parity action"}</Button></div>
        <div className={"tess-node tess-layout-content "} data-resource-variant={"nocturne"} data-node-id={"parity-mobile-omit"} data-semantic-role={"content"} data-responsive-strategy={"omit-nonessential"} style={({}) as React.CSSProperties}>{"Content omitted on mobile"}</div>
        <div className={"tess-node tess-layout-container "} data-resource-variant={"nocturne"} data-node-id={"parity-mobile-stack"} data-semantic-role={"container"} data-responsive-strategy={"stack"} style={({}) as React.CSSProperties}>
          <div className={"tess-node tess-layout-content "} data-resource-variant={"nocturne"} data-node-id={"parity-stack-child-one"} data-semantic-role={"content"} style={({}) as React.CSSProperties}>{"First stacked child"}</div>
          <div className={"tess-node tess-layout-content "} data-resource-variant={"nocturne"} data-node-id={"parity-stack-child-two"} data-semantic-role={"content"} style={({}) as React.CSSProperties}>{"Second stacked child"}</div>
        </div>
        <div className={"tess-node tess-layout-content "} data-resource-variant={"nocturne"} data-node-id={"parity-mobile-collapse"} data-semantic-role={"content"} data-responsive-strategy={"collapse"} style={({}) as React.CSSProperties}>{"Content with a collapsed mobile presentation"}</div>
        <div className={"@container tess-node tess-layout-dialog"} data-resource-variant={"quiet"} data-node-id={"parity-hostless-dialog"} data-semantic-role={"dialog"} style={({}) as React.CSSProperties}><Dialog variant={"quiet"} open={true} title={"Hostless dialog"}>{"Dialog closes with Escape."}</Dialog></div>
      </div>
    </div>
  );
}
