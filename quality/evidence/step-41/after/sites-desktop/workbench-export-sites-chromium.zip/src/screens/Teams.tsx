import React from 'react';
import { AdvancedDataTable } from '../components/AdvancedDataTable';
import { Button } from '../components/Button';
import { EntityProfileHeader } from '../components/EntityProfileHeader';
import { FilterBuilder } from '../components/FilterBuilder';
import { MinimalTopNav } from '../components/MinimalTopNav';

export function Teams() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-teams"}>
            <div className={"tess-node tess-layout-workspace-dock-shell "} data-resource-variant={"nocturne"} data-node-id={"root-screen-teams"} data-semantic-role={"workspace-dock-shell"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-navigation"} data-resource-variant={"nocturne"} data-node-id={"node-screen-teams-navigation-1"} data-semantic-role={"navigation"} style={({}) as React.CSSProperties}><MinimalTopNav variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Engagement","href":"#screen-engagement"},{"label":"Settings & Policies","href":"#screen-settings"}]} orientation={"vertical"} /></div>
        <div className={"tess-node tess-layout-workspace-multi-pane "} data-resource-variant={"nocturne"} data-node-id={"container-screen-teams-canvas"} data-semantic-role={"workspace-multi-pane"} style={({}) as React.CSSProperties}>
          <div className={"@container tess-node tess-layout-index-header"} data-resource-variant={"nocturne"} data-node-id={"node-screen-teams-index-header-2"} data-semantic-role={"index-header"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"Teams"} subtitle={"Explore team membership and shared priorities"} badge={"EXAMPLE"} initials={"PC"} /></div>
          <div className={"@container tess-node tess-layout-filter-bar"} data-resource-variant={"nocturne"} data-node-id={"node-screen-teams-filter-bar-3"} data-semantic-role={"filter-bar"} style={({}) as React.CSSProperties}><FilterBuilder variant={"nocturne"} /></div>
          <div className={"@container tess-node tess-layout-data-table"} data-resource-variant={"nocturne"} data-node-id={"node-screen-teams-data-table-4"} data-semantic-role={"data-table"} style={({}) as React.CSSProperties}><AdvancedDataTable variant={"nocturne"} title={"Team directory"} rows={[{"id":1,"name":"Example Product team","type":"Product planning and delivery · sample","quality":0,"status":"Membership not connected","displayValue":"Member count not connected"},{"id":2,"name":"Example Engineering team","type":"Engineering systems · sample","quality":0,"status":"Membership not connected","displayValue":"Member count not connected"},{"id":3,"name":"Example People team","type":"People operations · sample","quality":0,"status":"Membership not connected","displayValue":"Member count not connected"}]} columnLabels={{"name":"Team","type":"Focus","quality":"Members","status":"Status"}} /></div>
          <div className={"@container tess-node tess-layout-pagination"} data-resource-variant={"nocturne"} data-node-id={"node-screen-teams-pagination-5"} data-semantic-role={"pagination"} style={({}) as React.CSSProperties}><Button variant={"nocturne"} disabled={true}>{"Paging unavailable"}</Button></div>
        </div>
      </div>
    </div>
  );
}
