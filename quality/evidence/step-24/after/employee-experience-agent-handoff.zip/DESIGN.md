# Design system for `Adaptive Architecture — Employee experience`

## Visual direction

- **Archetype:** `recruitment`
- **Visual mode:** `dark`
- **Navigation model:** `rail`
- **Geometry:** `pill`
- **Surface personality:** `subtle-contrast`
- **Typography personality:** `geist-system`
- **Content tone:** `calm`
- **Responsive philosophy:** `desktop-dense-mobile-focused`
- **Motion personality:** `playful-spring`
- **Accessibility floor:** `AA`
- **Target devices:** `desktop`, `tablet`, `mobile`

## Exact Design DNA

`project.tess.json` is canonical. This snapshot is included for quick inspection.

```json
{
  "professionalism": 100,
  "playfulness": 53,
  "luxury": 40,
  "warmth": 45,
  "technicality": 65,
  "editorial": 35,
  "futurism": 35,
  "visualAmbition": 40,
  "structuralCreativity": 95,
  "density": 60,
  "whitespace": 65,
  "contrast": 75,
  "colourfulness": 54,
  "curvature": 63,
  "depth": 25,
  "motion": 25,
  "motionPlayfulness": 45,
  "typographicExpression": 35,
  "imageryIntensity": 25,
  "videoIntensity": 5,
  "threeDIntensity": 0,
  "dataDensity": 65,
  "interactionDensity": 80,
  "asymmetry": 80,
  "conversionIntensity": 55,
  "trust": 100,
  "accessibilityPriority": 85,
  "performancePriority": 82,
  "primaryArchetype": "recruitment",
  "visualMode": "dark",
  "geometryFamily": "pill",
  "navigationModel": "rail",
  "responsivePhilosophy": "desktop-dense-mobile-focused",
  "contentTone": "calm",
  "primaryStack": "react-tailwind",
  "motionPersonality": "playful-spring",
  "typographyPersonality": "geist-system",
  "surfacePersonality": "subtle-contrast"
}
```

## Normalized semantic tokens

```json
{
  "colors": {
    "canvas": "#0B0D10",
    "canvasStrong": "#111419",
    "surface": "#171B21",
    "surfaceRaised": "#1C2128",
    "border": "#272C34",
    "borderStrong": "#353C46",
    "textPrimary": "#F5F7FA",
    "textSecondary": "#A8AFBA",
    "textMuted": "#A8AFBA",
    "accent": "#6782FF",
    "accentHover": "#879DFF",
    "accentSoft": "#1C2752",
    "signalLime": "#C9FF57",
    "signalDanger": "#F87171",
    "signalSuccess": "#34D399",
    "signalWarning": "#FBBF24"
  },
  "typography": {
    "displayFont": "\"Geist\", Inter, system-ui, sans-serif",
    "headingFont": "\"Geist\", Inter, system-ui, sans-serif",
    "bodyFont": "\"Geist\", Inter, system-ui, sans-serif",
    "monoFont": "\"Geist Mono\", \"SFMono-Regular\", Consolas, monospace",
    "headingLetterSpacing": "-0.025em",
    "bodyLineHeight": 1.55,
    "scaleRatio": 1.235
  },
  "radius": {
    "xs": "4px",
    "sm": "8px",
    "md": "14px",
    "lg": "20.5px",
    "xl": "28.5px",
    "full": "999px"
  },
  "spacing": {
    "baseUnit": 4,
    "multiplier": 1.01,
    "gutterDesktop": "32px",
    "gutterMobile": "16px",
    "sectionGapDesktop": "112px",
    "sectionGapMobile": "72px"
  },
  "surfaceDepth": {
    "borderWidth": "1.5px",
    "shadowSubtle": "0 1px 2px rgba(17, 18, 23, 0.05)",
    "shadowMedium": "0 4px 12px rgba(17, 18, 23, 0.07)",
    "shadowStrong": "0 12px 36px rgba(17, 18, 23, 0.09)"
  },
  "motion": {
    "durationFast": "135ms",
    "durationNormal": "240ms",
    "durationSlow": "360ms",
    "easing": "cubic-bezier(0.34, 1.56, 0.64, 1)",
    "reducedMotion": false
  },
  "focus": {
    "ringColor": "#6782FF",
    "ringWidth": "3px",
    "ringOffset": "2px"
  }
}
```

## CSS custom properties

```css
:root {
  --tess-canvas: #0B0D10;
  --tess-canvas-strong: #111419;
  --tess-surface: #171B21;
  --tess-surface-raised: #1C2128;
  --tess-hairline: #272C34;
  --tess-hairline-strong: #353C46;
  --tess-ink: #F5F7FA;
  --tess-ink-secondary: #A8AFBA;
  --tess-ink-muted: #A8AFBA;
  --tess-accent: #6782FF;
  --tess-accent-primary: #6782FF;
  --tess-accent-ink: #111217;
  --tess-accent-hover: #879DFF;
  --tess-accent-soft: #1C2752;
  --tess-signal-lime: #C9FF57;
  --tess-signal-danger: #F87171;
  --tess-signal-success: #34D399;
  --tess-signal-warning: #FBBF24;
  --tess-font-display: "Geist", Inter, system-ui, sans-serif;
  --tess-font-heading: "Geist", Inter, system-ui, sans-serif;
  --tess-font-body: "Geist", Inter, system-ui, sans-serif;
  --tess-font-mono: "Geist Mono", "SFMono-Regular", Consolas, monospace;
  --tess-heading-letter-spacing: -0.025em;
  --tess-body-line-height: 1.55;
  --tess-type-scale-ratio: 1.235;
  --tess-space-md: 16px;
  --tess-space-lg: 24px;
  --tess-radius-xs: 4px;
  --tess-radius-sm: 8px;
  --tess-radius-md: 14px;
  --tess-radius-lg: 20.5px;
  --tess-radius-xl: 28.5px;
  --tess-radius-full: 999px;
  --tess-gutter-desktop: 32px;
  --tess-gutter-mobile: 16px;
  --tess-section-gap-desktop: 112px;
  --tess-section-gap-mobile: 72px;
  --tess-border-width: 1.5px;
  --tess-shadow-1: 0 1px 2px rgba(17, 18, 23, 0.05);
  --tess-shadow-2: 0 4px 12px rgba(17, 18, 23, 0.07);
  --tess-shadow-3: 0 12px 36px rgba(17, 18, 23, 0.09);
  --tess-duration-fast: 135ms;
  --tess-duration-normal: 240ms;
  --tess-duration-slow: 360ms;
  --tess-easing: cubic-bezier(0.34, 1.56, 0.64, 1);
  --tess-focus-ring-color: #6782FF;
  --tess-focus-ring-width: 3px;
  --tess-focus-ring-offset: 2px;
}
```

Use these tokens as the project styling source. Do not infer extra brand colors or alter the Design DNA without an explicit product decision.
