# Implementation outline for `Master-Detail Explorer — Employee experience`

This document is derived from the final ProjectManifest. It records the interface structure; it does not claim that an API, authentication system, cloud database, or persistence service exists.

## Export target

- **Target:** `vite-react-tailwind`
- **Framework:** `react`
- **Styling:** `tailwind`
- **Typed source:** yes
- **Catalogue version:** `0.1.0`
- **Target devices:** `desktop`, `tablet`, `mobile`

## Screen groups

- `Marketing`: `Marketing Home`
- `Application`: `Team Overview`, `People Directory`, `Teams`, `Engagement`
- `Account access`: `Onboarding`
- `Settings & administration`: `Settings & Policies`

## Screen path declarations

- **`Marketing Home`** — declared path `/`, screen ID `screen-marketing-home`, graph group `Marketing` — `Introduce a warm, connected employee experience`
- **`Team Overview`** — declared path `/overview`, screen ID `screen-overview`, graph group `Application` — `Refined employee summary and upcoming team actions`
- **`People Directory`** — declared path `/people`, screen ID `screen-collection-index`, graph group `Application` — `Find colleagues and their teams`
- **`Teams`** — declared path `/teams`, screen ID `screen-teams`, graph group `Application` — `Explore team membership and shared priorities`
- **`Engagement`** — declared path `/engagement`, screen ID `screen-engagement`, graph group `Application` — `Review employee feedback and recognition`
- **`Onboarding`** — declared path `/onboarding`, screen ID `screen-onboarding`, graph group `Account access` — `Playful welcome journey with clear milestones`
- **`Settings & Policies`** — declared path `/settings`, screen ID `screen-settings`, graph group `Settings & administration` — `Conservative policy acknowledgements and account preferences`

## Navigation behavior in the current standalone Vite export

The manifest records path slugs, but the current Vite source generator does not implement pathname routing. It switches screens with the URL fragment `#<screen-id>`. When a screen contains a navigation resource, the exporter binds that resource to the manifest's primary and secondary navigation items; otherwise it renders those items in the project shell. If no navigation items are declared, the shell falls back to the screen list. Hidden screens omitted from declared navigation remain available only through direct fragment links or explicit content links. Navigation targets below record both the declared path and the generated fragment so an implementer does not mistake one for the other. The fragment behavior is the current exported runtime; the path slug is the manifest's declared route intent.

## Navigation (`rail`)

- `Primary`: `Marketing Home` → `Marketing Home` (declared path `/`; current Vite export fragment `#screen-marketing-home`)
- `Primary`: `Team Overview` → `Team Overview` (declared path `/overview`; current Vite export fragment `#screen-overview`)
- `Primary`: `People Directory` → `People Directory` (declared path `/people`; current Vite export fragment `#screen-collection-index`)
- `Primary`: `Teams` → `Teams` (declared path `/teams`; current Vite export fragment `#screen-teams`)
- `Primary`: `Engagement` → `Engagement` (declared path `/engagement`; current Vite export fragment `#screen-engagement`)
- `Secondary`: `Settings & Policies` → `Settings & Policies` (declared path `/settings`; current Vite export fragment `#screen-settings`)

## Declared screen transitions

- `screen-marketing-home` → `screen-overview` — `Open the product`
- `screen-overview` → `screen-collection-index` — `People Directory`
- `screen-overview` → `screen-teams` — `Teams`
- `screen-overview` → `screen-engagement` — `Engagement`
- `screen-overview` → `screen-settings` — `Settings & Policies`

ScreenGraph transitions describe the planner's major product flow. Resource links and calls to action can declare additional destinations in their node props; those destinations are recorded separately in `COMPONENTS.md` and are not automatically added to ScreenGraph edges.

## Project constraints

```json
{
  "accessibilityFloor": "AA",
  "performanceCeiling": "rich",
  "targetDevices": [
    "desktop",
    "tablet",
    "mobile"
  ],
  "allowedDependencies": [
    "react",
    "tailwindcss",
    "lucide-react"
  ],
  "prohibitedDependencies": [
    "jquery",
    "bootstrap"
  ],
  "requiredScreens": [],
  "forbiddenScreens": [],
  "requiredPatterns": [],
  "forbiddenPatterns": []
}
```

The UI node hierarchy, resource versions, props, slots, and lock scopes are listed in `COMPONENTS.md`. Do not add service integrations or represent sample values as live data unless the project owner supplies those contracts.

## Handoff package boundaries

This ZIP contains project documentation and the canonical manifest only. It does not contain registry resource source, images/assets, tests, screenshots, or backend services. Resolve resource IDs, slugs, and individual resource versions against catalogue version `0.1.0` before implementation. The separate `dependencies.json` records baseline packages and flags declared dependency-policy conflicts for review.
