# Component inventory for `Adaptive Architecture — Employee experience`

Each entry is read from the manifest node tree. Resource IDs, slugs, versions, and variants are exact references; they do not include registry source code.

### `marketing-page` (`root-screen-marketing-home`)

- **Screen:** `Marketing Home`
- **Path:** `Marketing Home`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": {
    "playfulness": 65,
    "warmth": 82,
    "visualMode": "light"
  },
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-marketing-home-navigation-1`)

- **Screen:** `Marketing Home`
- **Path:** `Marketing Home` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `expressive`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "horizontal"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `hero` (`node-screen-marketing-home-hero-2`)

- **Screen:** `Marketing Home`
- **Path:** `Marketing Home` → `hero`
- **Node type:** `section`
- **Resource:** `editorial-hero@1.0.0 (ID res_sec_editorial_hero)`
- **Variant:** `expressive`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "eyebrow": "Example organisation · sample content",
    "headline": "A better workday starts with people.",
    "subheadline": "Bring your people, teams and everyday employee experiences together. A warm welcome, clear priorities and trusted policies.",
    "primaryCta": {
      "label": "Meet your team",
      "href": "#screen-teams"
    },
    "secondaryCta": {
      "label": "Explore onboarding",
      "href": "#screen-onboarding"
    },
    "note": "Example interface · replace sample data with your organisation"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `value-proposition` (`node-screen-marketing-home-value-proposition-3`)

- **Screen:** `Marketing Home`
- **Path:** `Marketing Home` → `value-proposition`
- **Node type:** `section`
- **Resource:** `feature-bento@1.0.0 (ID res_sec_feature_bento)`
- **Variant:** `expressive`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Made for everyday employee experiences",
    "items": [
      {
        "title": "A warm welcome",
        "description": "Meet your buddy, discover your team and complete onboarding at your own pace.",
        "detail": "Onboarding"
      },
      {
        "title": "People, connected",
        "description": "Find colleagues and understand the teams around you.",
        "detail": "People directory"
      },
      {
        "title": "A voice for everyone",
        "description": "Make space for feedback, recognition and conversations.",
        "detail": "Engagement"
      },
      {
        "title": "Clarity you can trust",
        "description": "Keep organisational policies and account preferences easy to find.",
        "detail": "Settings & policies"
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `conversion-cta` (`node-screen-marketing-home-conversion-cta-4`)

- **Screen:** `Marketing Home`
- **Path:** `Marketing Home` → `conversion-cta`
- **Node type:** `section`
- **Resource:** `cta-minimal@1.0.0 (ID res_sec_cta_minimal)`
- **Variant:** `expressive`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "headline": "A better workday starts with people.",
    "description": "Bring your people, teams and everyday employee experiences together. A warm welcome, clear priorities and trusted policies.",
    "label": "Meet your team",
    "href": "#screen-teams"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `footer` (`node-screen-marketing-home-footer-5`)

- **Screen:** `Marketing Home`
- **Path:** `Marketing Home` → `footer`
- **Node type:** `section`
- **Resource:** `footer-product@1.0.0 (ID res_sec_footer_product)`
- **Variant:** `expressive`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "description": "Bring your people, teams and everyday employee experiences together. A warm welcome, clear priorities and trusted policies.",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-dock-shell` (`root-screen-overview`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutVariant": "split-dock"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-overview-navigation-1`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "vertical"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-multi-pane` (`container-screen-overview-canvas`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview` → `workspace-multi-pane`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `overview-header` (`node-screen-overview-overview-header-2`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview` → `workspace-multi-pane` → `overview-header`
- **Node type:** `block`
- **Resource:** `entity-profile-header@1.0.0 (ID res_blk_entity_profile_header)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Team Overview",
    "subtitle": "Refined employee summary and upcoming team actions",
    "badge": "EXAMPLE",
    "initials": "PC"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `metric-cards` (`node-screen-overview-metric-cards-3`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview` → `workspace-multi-pane` → `metric-cards`
- **Node type:** `block`
- **Resource:** `dashboard-kpi-grid@1.0.0 (ID res_blk_dashboard_kpi_grid)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Your organisation at a glance",
    "cards": [
      {
        "label": "People",
        "val": "500",
        "status": "From your brief"
      },
      {
        "label": "Onboarding",
        "val": "—",
        "status": "No connected data"
      },
      {
        "label": "Team pulse",
        "val": "—",
        "status": "No connected data"
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `data-table` (`node-screen-overview-data-table-4`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview` → `workspace-multi-pane` → `data-table`
- **Node type:** `block`
- **Resource:** `advanced-data-table@1.0.0 (ID res_blk_advanced_data_table)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "People and teams",
    "rows": [
      {
        "id": 1,
        "name": "Example colleague A",
        "type": "Product team",
        "quality": 80,
        "status": "Onboarding",
        "displayValue": "Progress not connected"
      },
      {
        "id": 2,
        "name": "Example colleague B",
        "type": "Engineering team",
        "quality": 100,
        "status": "Settled in",
        "displayValue": "Progress not connected"
      },
      {
        "id": 3,
        "name": "Example colleague C",
        "type": "People team",
        "quality": 40,
        "status": "Welcome week",
        "displayValue": "Progress not connected"
      }
    ],
    "columnLabels": {
      "name": "Colleague",
      "type": "Team",
      "quality": "Progress",
      "status": "Status"
    }
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `activity-feed` (`node-screen-overview-activity-feed-5`)

- **Screen:** `Team Overview`
- **Path:** `Team Overview` → `workspace-multi-pane` → `activity-feed`
- **Node type:** `block`
- **Resource:** `timeline@1.0.0 (ID res_blk_timeline)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "People updates",
    "events": [
      {
        "time": "Today",
        "title": "Welcome to the team",
        "desc": "Meet your onboarding buddy and introduce yourself to colleagues."
      },
      {
        "time": "This week",
        "title": "Team check-in",
        "desc": "Share how your first week is going and ask for support."
      },
      {
        "time": "Next milestone",
        "title": "Policies and preferences",
        "desc": "Review organisational guidance and choose your notification preferences."
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-dock-shell` (`root-screen-collection-index`)

- **Screen:** `People Directory`
- **Path:** `People Directory`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutVariant": "split-dock"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-collection-index-navigation-1`)

- **Screen:** `People Directory`
- **Path:** `People Directory` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "vertical"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-multi-pane` (`container-screen-collection-index-canvas`)

- **Screen:** `People Directory`
- **Path:** `People Directory` → `workspace-multi-pane`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `index-header` (`node-screen-collection-index-index-header-2`)

- **Screen:** `People Directory`
- **Path:** `People Directory` → `workspace-multi-pane` → `index-header`
- **Node type:** `block`
- **Resource:** `entity-profile-header@1.0.0 (ID res_blk_entity_profile_header)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "People Directory",
    "subtitle": "Find colleagues and their teams",
    "badge": "EXAMPLE",
    "initials": "PC"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `filter-bar` (`node-screen-collection-index-filter-bar-3`)

- **Screen:** `People Directory`
- **Path:** `People Directory` → `workspace-multi-pane` → `filter-bar`
- **Node type:** `block`
- **Resource:** `filter-builder@1.0.0 (ID res_blk_filter_builder)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {},
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `data-table` (`node-screen-collection-index-data-table-4`)

- **Screen:** `People Directory`
- **Path:** `People Directory` → `workspace-multi-pane` → `data-table`
- **Node type:** `block`
- **Resource:** `advanced-data-table@1.0.0 (ID res_blk_advanced_data_table)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "People and teams",
    "rows": [
      {
        "id": 1,
        "name": "Example colleague A",
        "type": "Product team",
        "quality": 80,
        "status": "Onboarding",
        "displayValue": "Progress not connected"
      },
      {
        "id": 2,
        "name": "Example colleague B",
        "type": "Engineering team",
        "quality": 100,
        "status": "Settled in",
        "displayValue": "Progress not connected"
      },
      {
        "id": 3,
        "name": "Example colleague C",
        "type": "People team",
        "quality": 40,
        "status": "Welcome week",
        "displayValue": "Progress not connected"
      }
    ],
    "columnLabels": {
      "name": "Colleague",
      "type": "Team",
      "quality": "Progress",
      "status": "Status"
    }
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `pagination` (`node-screen-collection-index-pagination-5`)

- **Screen:** `People Directory`
- **Path:** `People Directory` → `workspace-multi-pane` → `pagination`
- **Node type:** `element`
- **Resource:** `button@1.0.0 (ID res_primitive_button_01)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "children": "Paging unavailable",
    "disabled": true,
    "title": "Connect a paging data source before navigating additional records.",
    "helperText": "Example field. Connect persistence and your backend in the exported application."
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-dock-shell` (`root-screen-teams`)

- **Screen:** `Teams`
- **Path:** `Teams`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutVariant": "split-dock"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-teams-navigation-1`)

- **Screen:** `Teams`
- **Path:** `Teams` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "vertical"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-multi-pane` (`container-screen-teams-canvas`)

- **Screen:** `Teams`
- **Path:** `Teams` → `workspace-multi-pane`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `index-header` (`node-screen-teams-index-header-2`)

- **Screen:** `Teams`
- **Path:** `Teams` → `workspace-multi-pane` → `index-header`
- **Node type:** `block`
- **Resource:** `entity-profile-header@1.0.0 (ID res_blk_entity_profile_header)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Teams",
    "subtitle": "Explore team membership and shared priorities",
    "badge": "EXAMPLE",
    "initials": "PC"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `filter-bar` (`node-screen-teams-filter-bar-3`)

- **Screen:** `Teams`
- **Path:** `Teams` → `workspace-multi-pane` → `filter-bar`
- **Node type:** `block`
- **Resource:** `filter-builder@1.0.0 (ID res_blk_filter_builder)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {},
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `data-table` (`node-screen-teams-data-table-4`)

- **Screen:** `Teams`
- **Path:** `Teams` → `workspace-multi-pane` → `data-table`
- **Node type:** `block`
- **Resource:** `advanced-data-table@1.0.0 (ID res_blk_advanced_data_table)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Team directory",
    "rows": [
      {
        "id": 1,
        "name": "Example Product team",
        "type": "Product planning and delivery · sample",
        "quality": 0,
        "status": "Membership not connected",
        "displayValue": "Member count not connected"
      },
      {
        "id": 2,
        "name": "Example Engineering team",
        "type": "Engineering systems · sample",
        "quality": 0,
        "status": "Membership not connected",
        "displayValue": "Member count not connected"
      },
      {
        "id": 3,
        "name": "Example People team",
        "type": "People operations · sample",
        "quality": 0,
        "status": "Membership not connected",
        "displayValue": "Member count not connected"
      }
    ],
    "columnLabels": {
      "name": "Team",
      "type": "Focus",
      "quality": "Members",
      "status": "Status"
    }
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `pagination` (`node-screen-teams-pagination-5`)

- **Screen:** `Teams`
- **Path:** `Teams` → `workspace-multi-pane` → `pagination`
- **Node type:** `element`
- **Resource:** `button@1.0.0 (ID res_primitive_button_01)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "children": "Paging unavailable",
    "disabled": true,
    "title": "Connect a paging data source before navigating additional records.",
    "helperText": "Example field. Connect persistence and your backend in the exported application."
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-dock-shell` (`root-screen-engagement`)

- **Screen:** `Engagement`
- **Path:** `Engagement`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutVariant": "split-dock"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-engagement-navigation-1`)

- **Screen:** `Engagement`
- **Path:** `Engagement` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "vertical"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-multi-pane` (`container-screen-engagement-canvas`)

- **Screen:** `Engagement`
- **Path:** `Engagement` → `workspace-multi-pane`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `overview-header` (`node-screen-engagement-overview-header-2`)

- **Screen:** `Engagement`
- **Path:** `Engagement` → `workspace-multi-pane` → `overview-header`
- **Node type:** `block`
- **Resource:** `entity-profile-header@1.0.0 (ID res_blk_entity_profile_header)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Engagement",
    "subtitle": "Review employee feedback and recognition",
    "badge": "EXAMPLE",
    "initials": "PC"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `metric-cards` (`node-screen-engagement-metric-cards-3`)

- **Screen:** `Engagement`
- **Path:** `Engagement` → `workspace-multi-pane` → `metric-cards`
- **Node type:** `block`
- **Resource:** `dashboard-kpi-grid@1.0.0 (ID res_blk_dashboard_kpi_grid)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Engagement overview",
    "cards": [
      {
        "label": "Feedback",
        "val": "—",
        "status": "No connected data"
      },
      {
        "label": "Recognition",
        "val": "—",
        "status": "No connected data"
      },
      {
        "label": "Participation",
        "val": "—",
        "status": "No connected data"
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `data-table` (`node-screen-engagement-data-table-4`)

- **Screen:** `Engagement`
- **Path:** `Engagement` → `workspace-multi-pane` → `data-table`
- **Node type:** `block`
- **Resource:** `advanced-data-table@1.0.0 (ID res_blk_advanced_data_table)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Feedback and recognition",
    "rows": [
      {
        "id": 1,
        "name": "Example feedback topic",
        "type": "Employee feedback · sample",
        "quality": 0,
        "status": "Responses not connected",
        "displayValue": "No connected data"
      },
      {
        "id": 2,
        "name": "Example peer recognition",
        "type": "Recognition · sample",
        "quality": 0,
        "status": "Responses not connected",
        "displayValue": "No connected data"
      },
      {
        "id": 3,
        "name": "Example team pulse",
        "type": "Engagement check-in · sample",
        "quality": 0,
        "status": "Responses not connected",
        "displayValue": "No connected data"
      }
    ],
    "columnLabels": {
      "name": "Item",
      "type": "Type",
      "quality": "Details",
      "status": "Status"
    }
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `activity-feed` (`node-screen-engagement-activity-feed-5`)

- **Screen:** `Engagement`
- **Path:** `Engagement` → `workspace-multi-pane` → `activity-feed`
- **Node type:** `block`
- **Resource:** `timeline@1.0.0 (ID res_blk_timeline)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Feedback and recognition",
    "events": [
      {
        "time": "This week",
        "title": "Example feedback check-in",
        "desc": "Sample prompt: what would help your team work well together? Responses are not connected."
      },
      {
        "time": "Today",
        "title": "Example peer recognition",
        "desc": "Sample recognition for a colleague contribution. No employee activity is connected."
      },
      {
        "time": "Next week",
        "title": "Example team pulse",
        "desc": "Sample engagement check-in. Participation data is not connected."
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-dock-shell` (`root-screen-onboarding`)

- **Screen:** `Onboarding`
- **Path:** `Onboarding`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutVariant": "split-dock"
  },
  "slots": {},
  "dnaOverrides": {
    "playfulness": 75,
    "warmth": 78,
    "curvature": 65,
    "motionPlayfulness": 55
  },
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-onboarding-navigation-1`)

- **Screen:** `Onboarding`
- **Path:** `Onboarding` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "vertical"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-multi-pane` (`container-screen-onboarding-canvas`)

- **Screen:** `Onboarding`
- **Path:** `Onboarding` → `workspace-multi-pane`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `progress-stepper` (`node-screen-onboarding-progress-stepper-2`)

- **Screen:** `Onboarding`
- **Path:** `Onboarding` → `workspace-multi-pane` → `progress-stepper`
- **Node type:** `block`
- **Resource:** `timeline@1.0.0 (ID res_blk_timeline)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Welcome milestones",
    "events": [
      {
        "time": "Today",
        "title": "Welcome to the team",
        "desc": "Meet your onboarding buddy and introduce yourself to colleagues."
      },
      {
        "time": "This week",
        "title": "Team check-in",
        "desc": "Share how your first week is going and ask for support."
      },
      {
        "time": "Next milestone",
        "title": "Policies and preferences",
        "desc": "Review organisational guidance and choose your notification preferences."
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `wizard-content` (`node-screen-onboarding-wizard-content-3`)

- **Screen:** `Onboarding`
- **Path:** `Onboarding` → `workspace-multi-pane` → `wizard-content`
- **Node type:** `block`
- **Resource:** `kanban-board@1.0.0 (ID res_blk_kanban_board)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "title": "Your onboarding journey",
    "columns": [
      {
        "title": "Discover",
        "tasks": [
          "Meet your buddy",
          "Find your team"
        ]
      },
      {
        "title": "Connect",
        "tasks": [
          "Introduce yourself",
          "Join a team check-in"
        ]
      },
      {
        "title": "Feel at home",
        "tasks": [
          "Read organisational policies",
          "Share your first-week feedback"
        ]
      }
    ]
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `action-controls` (`node-screen-onboarding-action-controls-4`)

- **Screen:** `Onboarding`
- **Path:** `Onboarding` → `workspace-multi-pane` → `action-controls`
- **Node type:** `element`
- **Resource:** `button@1.0.0 (ID res_primitive_button_01)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "children": "Connect an action to continue",
    "disabled": true,
    "title": "Connect the exported application to your backend to enable this action.",
    "helperText": "Example field. Connect persistence and your backend in the exported application."
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-dock-shell` (`root-screen-settings`)

- **Screen:** `Settings & Policies`
- **Path:** `Settings & Policies`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutVariant": "split-dock"
  },
  "slots": {},
  "dnaOverrides": {
    "professionalism": 96,
    "playfulness": 8,
    "curvature": 12,
    "motion": 10
  },
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `navigation` (`node-screen-settings-navigation-1`)

- **Screen:** `Settings & Policies`
- **Path:** `Settings & Policies` → `navigation`
- **Node type:** `layout`
- **Resource:** `minimal-top-nav@1.0.0 (ID res_shell_minimal_top_nav)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "brand": "People & Co",
    "links": [
      {
        "label": "Marketing Home",
        "href": "#screen-marketing-home"
      },
      {
        "label": "Team Overview",
        "href": "#screen-overview"
      },
      {
        "label": "People Directory",
        "href": "#screen-collection-index"
      },
      {
        "label": "Teams",
        "href": "#screen-teams"
      },
      {
        "label": "Engagement",
        "href": "#screen-engagement"
      },
      {
        "label": "Settings & Policies",
        "href": "#screen-settings"
      }
    ],
    "orientation": "vertical"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `workspace-multi-pane` (`container-screen-settings-canvas`)

- **Screen:** `Settings & Policies`
- **Path:** `Settings & Policies` → `workspace-multi-pane`
- **Node type:** `layout`
- **Resource:** `No catalogue resource assigned`
- **Variant:** `default`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "layoutFamily": "tri-column-intelligence"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `settings-form` (`node-screen-settings-settings-form-2`)

- **Screen:** `Settings & Policies`
- **Path:** `Settings & Policies` → `workspace-multi-pane` → `settings-form`
- **Node type:** `element`
- **Resource:** `input@1.0.0 (ID res_primitive_input)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "label": "Policy acknowledgement (preview only)",
    "helperText": "Sample respectful workplace and information security guidance. Replace with approved company text; acknowledgements are not stored in this preview.",
    "placeholder": "Local preview — not saved",
    "disabled": false,
    "title": "Settings & Policies"
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```

### `save-footer` (`node-screen-settings-save-footer-3`)

- **Screen:** `Settings & Policies`
- **Path:** `Settings & Policies` → `workspace-multi-pane` → `save-footer`
- **Node type:** `element`
- **Resource:** `button@1.0.0 (ID res_primitive_button_01)`
- **Variant:** `nocturne`
- **Locks:** No lock declared

Props, slots, overrides, and local lock fields:

```json
{
  "props": {
    "children": "Save preferences",
    "disabled": true,
    "title": "Connect persistence to save.",
    "helperText": "Connect persistence to save."
  },
  "slots": {},
  "dnaOverrides": null,
  "tokenOverrides": null,
  "responsiveOverrides": null,
  "locks": null
}
```
