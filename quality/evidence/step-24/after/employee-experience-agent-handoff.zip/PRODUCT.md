# Product definition for `Adaptive Architecture — Employee experience`

## Summary

- **Project ID:** `proj-direction-c-0158f2b53bec41e484aad0d9c7808524dirc`
- **Description:** `Build a professional but playful employee experience platform for a 500-person technology company. The marketing site should feel warm and energetic, while the application itself should feel professional, fast and trustworthy. Make the dashboard refined, make onboarding playful, keep settings conservative.`
- **Brand:** `People & Co`
- **Primary audience:** `Employees, team leads and people operations teams`
- **Primary objective:** `Deliver a connected employee experience where colleagues build team relationships, complete onboarding, share feedback and access organisational policies`
- **Archetypes:** `recruitment (100%)`
- **Secondary objectives:** `Ensure high accessibility standards`, `Maintain responsive layout across devices`

## Jobs to be done

- `Authenticate and access Employee Experience`
- `Review the overview and priority actions`
- `Create, update, and manage records`
- `Welcome a colleague and complete onboarding milestones`
- `Share a team pulse and recognise a colleague`
- `Review organisational policies and notification preferences`

## Product entities

### `Employee`

`A colleague with a team, role and onboarding progress`

Fields: `id`, `name`, `team`, `role`, `onboardingStatus`

### `Team`

`A group of colleagues with a shared purpose and manager`

Fields: `id`, `name`, `manager`, `members`

### `Policy`

`Organisational guidance with acknowledgement history`

Fields: `id`, `title`, `version`, `acknowledgedAt`

## Workflows

### `Welcome a colleague and complete onboarding milestones`

1. `meet-buddy`
2. `read-policies`
3. `join-team`
4. `complete-check-in`

### `Share a team pulse and recognise a colleague`

1. `share-feedback`
2. `recognise-colleague`
3. `review-team-pulse`

### `Review organisational policies and notification preferences`

1. `read-policy`
2. `acknowledge-policy`
3. `save-preferences`

## Intended screens

- `Marketing Home` — `Introduce a warm, connected employee experience` (type `marketing`, required)
- `Team Overview` — `Refined employee summary and upcoming team actions` (type `dashboard`, required)
- `People Directory` — `Find colleagues and their teams` (type `index-list`, required)
- `Teams` — `Explore team membership and shared priorities` (type `index-list`, required)
- `Onboarding` — `Playful welcome journey with clear milestones` (type `onboarding`, required)
- `Engagement` — `Review employee feedback and recognition` (type `dashboard`, required)
- `Settings & Policies` — `Conservative policy acknowledgements and account preferences` (type `settings`, required)

## Product constraints

```json
{
  "requiredCapabilities": [
    "people-directory",
    "team-membership",
    "onboarding-checklist",
    "policy-acknowledgements"
  ],
  "forbiddenPatterns": [
    "unblinded-evaluations-causing-bias",
    "accidental-rejection-email-dispatches"
  ],
  "constraints": {
    "accessibilityFloor": "AA",
    "performanceCeiling": "rich",
    "targetDevices": [
      "desktop",
      "tablet",
      "mobile"
    ],
    "allowedDependencies": [
      "react",
      "tailwindcss",
      "lucide-react"
    ],
    "prohibitedDependencies": [
      "jquery",
      "bootstrap"
    ],
    "requiredScreens": [],
    "forbiddenScreens": [],
    "requiredPatterns": [],
    "forbiddenPatterns": [
      "unblinded-evaluations-causing-bias",
      "accidental-rejection-email-dispatches"
    ]
  },
  "trustRequirement": 88,
  "informationComplexity": 55,
  "dataDensity": 55,
  "collaborationLevel": 80,
  "transactionCriticality": 30,
  "mobileImportance": 60
}
```

Manifest text and example values describe project intent. They are not evidence of actual customers, usage, or live operational data.
