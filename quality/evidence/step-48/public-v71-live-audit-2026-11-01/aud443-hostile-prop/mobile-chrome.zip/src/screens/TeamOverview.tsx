import React from 'react';
import { AdvancedDataTable } from '../components/AdvancedDataTable';
import { CollapsibleSidebar } from '../components/CollapsibleSidebar';
import { DashboardKpiGrid } from '../components/DashboardKpiGrid';
import { EntityProfileHeader } from '../components/EntityProfileHeader';
import { Timeline } from '../components/Timeline';

export function TeamOverview() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-overview"}>
            <div className={"tess-node tess-layout-workspace-dock-shell "} data-resource-variant={null} data-node-id={"root-screen-overview"} data-semantic-role={"workspace-dock-shell"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-navigation"} data-resource-variant={"nocturne"} data-node-id={"node-screen-overview-navigation-1"} data-semantic-role={"navigation"} style={({}) as React.CSSProperties}><CollapsibleSidebar variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Engagement","href":"#screen-engagement"},{"label":"Settings & Policies","href":"#screen-settings"}]} /></div>
        <div className={"tess-node tess-layout-workspace-multi-pane "} data-resource-variant={null} data-node-id={"container-screen-overview-canvas"} data-semantic-role={"workspace-multi-pane"} style={({}) as React.CSSProperties}>
          <div className={"@container tess-node tess-layout-overview-header"} data-resource-variant={"nocturne"} data-node-id={"node-screen-overview-overview-header-2"} data-semantic-role={"overview-header"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"Team Overview"} subtitle={"Refined employee summary and upcoming team actions"} badge={"EXAMPLE"} initials={"PC"} /></div>
          <div className={"@container tess-node tess-layout-metric-cards"} data-resource-variant={"nocturne"} data-node-id={"node-screen-overview-metric-cards-3"} data-semantic-role={"metric-cards"} style={({}) as React.CSSProperties}><DashboardKpiGrid variant={"nocturne"} title={"Your organisation at a glance"} cards={[{"label":"People","val":"—","status":"No connected data"},{"label":"Onboarding","val":"—","status":"No connected data"},{"label":"Team pulse","val":"—","status":"No connected data"}]} /></div>
          <div className={"@container tess-node tess-layout-data-table"} data-resource-variant={"nocturne"} data-node-id={"node-screen-overview-data-table-4"} data-semantic-role={"data-table"} style={({}) as React.CSSProperties}><AdvancedDataTable variant={"nocturne"} title={"People and teams"} rows={[{"id":1,"name":"Example colleague A","type":"Product team","quality":80,"status":"Onboarding","displayValue":"Progress not connected"},{"id":2,"name":"Example colleague B","type":"Engineering team","quality":100,"status":"Settled in","displayValue":"Progress not connected"},{"id":3,"name":"Example colleague C","type":"People team","quality":40,"status":"Welcome week","displayValue":"Progress not connected"}]} columnLabels={{"name":"Colleague","type":"Team","quality":"Progress","status":"Status"}} /></div>
          <div className={"@container tess-node tess-layout-activity-feed"} data-resource-variant={"nocturne"} data-node-id={"node-screen-overview-activity-feed-5"} data-semantic-role={"activity-feed"} style={({}) as React.CSSProperties}><Timeline variant={"nocturne"} title={"People updates"} events={[{"time":"Today","title":"Welcome to the team","desc":"Meet your onboarding buddy and introduce yourself to colleagues."},{"time":"This week","title":"Team check-in","desc":"Share how your first week is going and ask for support."},{"time":"Next milestone","title":"Policies and preferences","desc":"Review organisational guidance and choose your notification preferences."}]} /></div>
        </div>
      </div>
    </div>
  );
}
