import React, { useState, useEffect } from 'react';
import { MarketingHome } from './screens/MarketingHome';
import { TeamOverview } from './screens/TeamOverview';
import { PeopleDirectory } from './screens/PeopleDirectory';
import { Teams } from './screens/Teams';
import { Engagement } from './screens/Engagement';
import { Onboarding } from './screens/Onboarding';
import { SettingsPolicies } from './screens/SettingsPolicies';

export default function App() {
  const screens = ["screen-marketing-home","screen-overview","screen-collection-index","screen-teams","screen-engagement","screen-onboarding","screen-settings"];
  const screensWithEmbeddedNavigation: Record<string, boolean> = {"screen-marketing-home":true,"screen-overview":true,"screen-collection-index":true,"screen-teams":true,"screen-engagement":true,"screen-onboarding":true,"screen-settings":true};
  const readScreen=()=>{try{const id=decodeURIComponent(location.hash.slice(1));return screens.includes(id)?id:screens[0];}catch{return screens[0];}};
  const [activeScreenId,setActiveScreenId]=useState(readScreen);
  useEffect(()=>{const handle=()=>setActiveScreenId(readScreen());window.addEventListener('hashchange',handle);return ()=>window.removeEventListener('hashchange',handle);},[]);


  const renderActiveScreen = () => {
    switch (activeScreenId) {
      case "screen-marketing-home": return <MarketingHome />;
      case "screen-overview": return <TeamOverview />;
      case "screen-collection-index": return <PeopleDirectory />;
      case "screen-teams": return <Teams />;
      case "screen-engagement": return <Engagement />;
      case "screen-onboarding": return <Onboarding />;
      case "screen-settings": return <SettingsPolicies />;
      default:
        return <MarketingHome />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--tess-canvas,#FAF9F6)] text-[var(--tess-ink,#111217)] font-sans">
      {!screensWithEmbeddedNavigation[activeScreenId] && (
      <header className="border-b border-[var(--tess-hairline,#D9D6CF)] bg-[var(--tess-surface)] px-4 py-3 flex flex-col sm:flex-row sm:flex-wrap gap-3 items-start sm:items-center justify-between">
        <div className="font-bold text-sm tracking-tight">{"AUD-443 prop-name safety audit desktop-chrome"}</div>
        <nav aria-label="Project navigation" className="flex flex-nowrap items-center gap-2 min-w-0 max-w-full overflow-x-auto whitespace-nowrap pb-1">
          <a
            href={"#screen-marketing-home"} aria-current={activeScreenId === "screen-marketing-home" ? 'page' : undefined}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-marketing-home"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Marketing Home"}
          </a>
          <a
            href={"#screen-overview"} aria-current={activeScreenId === "screen-overview" ? 'page' : undefined}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-overview"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Team Overview"}
          </a>
          <a
            href={"#screen-collection-index"} aria-current={activeScreenId === "screen-collection-index" ? 'page' : undefined}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-collection-index"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"People Directory"}
          </a>
          <a
            href={"#screen-teams"} aria-current={activeScreenId === "screen-teams" ? 'page' : undefined}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-teams"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Teams"}
          </a>
          <a
            href={"#screen-engagement"} aria-current={activeScreenId === "screen-engagement" ? 'page' : undefined}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-engagement"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Engagement"}
          </a>
          <a
            href={"#screen-settings"} aria-current={activeScreenId === "screen-settings" ? 'page' : undefined}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeScreenId === "screen-settings"
                ? 'bg-[var(--tess-accent-primary,#2547E8)] text-[var(--tess-accent-ink,#FFFFFF)] shadow-xs'
                : 'text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]'
            }`}
          >
            {"Settings & Policies"}
          </a>
        </nav>
      </header>
    )}

      {/* Screen Container */}
      <main className="flex-1">
        {renderActiveScreen()}
      </main>
    </div>
  );
}
