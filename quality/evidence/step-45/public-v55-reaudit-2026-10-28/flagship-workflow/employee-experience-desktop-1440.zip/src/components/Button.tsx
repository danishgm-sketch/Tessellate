import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'ghost' | 'quiet' | 'expressive' | 'nocturne';
  label?: string;
}

export function Button({ variant = 'primary', label, children, className = '', ...props }: ButtonProps) {
  const base = "inline-flex items-center justify-center font-medium transition-colors cursor-pointer select-none text-xs px-3.5 py-1.5 rounded-[var(--tess-radius-sm,6px)]";
  const styles: Record<string, string> = {
    primary: "bg-[var(--tess-accent-primary,#2547E8)] text-white hover:opacity-90 shadow-xs",
    outline: "border border-[var(--tess-hairline,#D9D6CF)] text-[var(--tess-ink,#111217)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]",
    ghost: "text-[var(--tess-ink-secondary,#62666F)] hover:bg-[var(--tess-surface-secondary,#F2EFE9)]",
    quiet: "bg-neutral-900 text-white hover:opacity-90",
    expressive: "bg-[#2547E8] text-white shadow-md hover:bg-blue-700",
    nocturne: "bg-[#06B6D4] text-neutral-950 font-bold hover:bg-cyan-400",
  };
  return (
    <button className={`${base} ${styles[variant] ?? styles.primary} ${className}`} {...props}>
      {label || children}
    </button>
  );
}
