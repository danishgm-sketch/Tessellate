import React from 'react';

export interface AppHeaderProps {
  title?: string;
  navItems?: Array<{ label: string; href?: string; active?: boolean }>;
}

export function AppHeader({ title = 'Application', navItems = [] }: AppHeaderProps) {
  return (
    <header className="h-16 px-6 border-b border-[var(--tess-hairline,#D9D6CF)] bg-white dark:bg-[#171B21] flex items-center justify-between">
      <div className="text-sm font-bold tracking-tight text-[var(--tess-ink,#111217)]">
        {title}
      </div>
      {navItems.length > 0 && (
        <nav className="flex items-center gap-4 text-xs font-medium">
          {navItems.map((item, i) => (
            <a
              key={i}
              href={item.href || '#'}
              className={`transition-colors ${item.active ? 'text-[var(--tess-accent-primary,#2547E8)] font-semibold' : 'text-[var(--tess-ink-secondary,#62666F)] hover:text-[var(--tess-ink,#111217)]'}`}
            >
              {item.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
