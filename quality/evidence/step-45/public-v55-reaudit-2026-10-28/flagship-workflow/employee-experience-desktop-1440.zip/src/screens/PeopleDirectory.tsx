import React from 'react';
import { AdvancedDataTable } from '../components/AdvancedDataTable';
import { Button } from '../components/Button';
import { EntityProfileHeader } from '../components/EntityProfileHeader';
import { FilterBuilder } from '../components/FilterBuilder';
import { MinimalTopNav } from '../components/MinimalTopNav';

export function PeopleDirectory() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-collection-index"}>
            <div className={"tess-node tess-layout-top-nav-page-canvas "} data-resource-variant={"nocturne"} data-node-id={"root-screen-collection-index"} data-semantic-role={"top-nav-page-canvas"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-navigation"} data-resource-variant={"nocturne"} data-node-id={"node-screen-collection-index-navigation-1"} data-semantic-role={"navigation"} style={({}) as React.CSSProperties}><MinimalTopNav variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Engagement","href":"#screen-engagement"}]} orientation={"horizontal"} /></div>
        <div className={"@container tess-node tess-layout-index-header"} data-resource-variant={"nocturne"} data-node-id={"node-screen-collection-index-index-header-2"} data-semantic-role={"index-header"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"People Directory"} subtitle={"Find colleagues and their teams"} badge={"EXAMPLE"} initials={"PC"} /></div>
        <div className={"@container tess-node tess-layout-filter-bar"} data-resource-variant={"nocturne"} data-node-id={"node-screen-collection-index-filter-bar-3"} data-semantic-role={"filter-bar"} style={({}) as React.CSSProperties}><FilterBuilder variant={"nocturne"} /></div>
        <div className={"@container tess-node tess-layout-data-table"} data-resource-variant={"nocturne"} data-node-id={"node-screen-collection-index-data-table-4"} data-semantic-role={"data-table"} style={({}) as React.CSSProperties}><AdvancedDataTable variant={"nocturne"} title={"People and teams"} rows={[{"id":1,"name":"Example colleague A","type":"Product team","quality":80,"status":"Onboarding","displayValue":"Progress not connected"},{"id":2,"name":"Example colleague B","type":"Engineering team","quality":100,"status":"Settled in","displayValue":"Progress not connected"},{"id":3,"name":"Example colleague C","type":"People team","quality":40,"status":"Welcome week","displayValue":"Progress not connected"}]} columnLabels={{"name":"Colleague","type":"Team","quality":"Progress","status":"Status"}} /></div>
        <div className={"@container tess-node tess-layout-pagination"} data-resource-variant={"nocturne"} data-node-id={"node-screen-collection-index-pagination-5"} data-semantic-role={"pagination"} style={({}) as React.CSSProperties}><Button variant={"nocturne"} disabled={true}>{"Paging unavailable"}</Button></div>
      </div>
    </div>
  );
}
