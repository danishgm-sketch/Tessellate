import React from 'react';
import { AdvancedDataTable } from '../components/AdvancedDataTable';
import { DashboardKpiGrid } from '../components/DashboardKpiGrid';
import { EntityProfileHeader } from '../components/EntityProfileHeader';
import { MinimalTopNav } from '../components/MinimalTopNav';
import { Timeline } from '../components/Timeline';

export function Engagement() {
  
  return (
    <div className="tess-screen w-full min-h-screen" data-screen-id={"screen-engagement"}>
            <div className={"tess-node tess-layout-workspace-dock-shell "} data-resource-variant={"nocturne"} data-node-id={"root-screen-engagement"} data-semantic-role={"workspace-dock-shell"} style={({}) as React.CSSProperties}>
        <div className={"@container tess-node tess-layout-navigation"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-navigation-1"} data-semantic-role={"navigation"} style={({}) as React.CSSProperties}><MinimalTopNav variant={"nocturne"} brand={"People & Co"} links={[{"label":"Marketing Home","href":"#screen-marketing-home"},{"label":"Team Overview","href":"#screen-overview"},{"label":"People Directory","href":"#screen-collection-index"},{"label":"Teams","href":"#screen-teams"},{"label":"Engagement","href":"#screen-engagement"}]} orientation={"vertical"} /></div>
        <div className={"tess-node tess-layout-workspace-multi-pane "} data-resource-variant={"nocturne"} data-node-id={"container-screen-engagement-canvas"} data-semantic-role={"workspace-multi-pane"} style={({}) as React.CSSProperties}>
          <div className={"@container tess-node tess-layout-overview-header"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-overview-header-2"} data-semantic-role={"overview-header"} style={({}) as React.CSSProperties}><EntityProfileHeader variant={"nocturne"} title={"Engagement"} subtitle={"Review employee feedback and recognition"} badge={"EXAMPLE"} initials={"PC"} /></div>
          <div className={"@container tess-node tess-layout-metric-cards"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-metric-cards-3"} data-semantic-role={"metric-cards"} style={({}) as React.CSSProperties}><DashboardKpiGrid variant={"nocturne"} title={"Engagement overview"} cards={[{"label":"Feedback","val":"—","status":"No connected data"},{"label":"Recognition","val":"—","status":"No connected data"},{"label":"Participation","val":"—","status":"No connected data"}]} /></div>
          <div className={"@container tess-node tess-layout-data-table"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-data-table-4"} data-semantic-role={"data-table"} style={({}) as React.CSSProperties}><AdvancedDataTable variant={"nocturne"} title={"Feedback and recognition"} rows={[{"id":1,"name":"Example feedback topic","type":"Employee feedback · sample","quality":0,"status":"Responses not connected","displayValue":"No connected data"},{"id":2,"name":"Example peer recognition","type":"Recognition · sample","quality":0,"status":"Responses not connected","displayValue":"No connected data"},{"id":3,"name":"Example team pulse","type":"Engagement check-in · sample","quality":0,"status":"Responses not connected","displayValue":"No connected data"}]} columnLabels={{"name":"Item","type":"Type","quality":"Details","status":"Status"}} /></div>
          <div className={"@container tess-node tess-layout-activity-feed"} data-resource-variant={"nocturne"} data-node-id={"node-screen-engagement-activity-feed-5"} data-semantic-role={"activity-feed"} style={({}) as React.CSSProperties}><Timeline variant={"nocturne"} title={"Feedback and recognition"} events={[{"time":"This week","title":"Example feedback check-in","desc":"Sample prompt: what would help your team work well together? Responses are not connected."},{"time":"Today","title":"Example peer recognition","desc":"Sample recognition for a colleague contribution. No employee activity is connected."},{"time":"Next week","title":"Example team pulse","desc":"Sample engagement check-in. Participation data is not connected."}]} /></div>
        </div>
      </div>
    </div>
  );
}
