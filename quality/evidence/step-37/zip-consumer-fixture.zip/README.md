# Tessellate ZIP consumer fixture

Independent extraction check.
